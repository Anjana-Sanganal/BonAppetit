package com.app.pojos;

public enum Role 
{
	ADMIN,HOTEL_OWNER,CUSTOMER;
}
