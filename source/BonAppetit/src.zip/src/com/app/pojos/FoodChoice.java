package com.app.pojos;

public enum FoodChoice 
{
	VEG,NON_VEG;
}
